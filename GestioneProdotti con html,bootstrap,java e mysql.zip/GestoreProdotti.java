package GestioneProdotti;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GestoreProdotti extends JFrame{
	private String nome1;
	private String descrizione1;
	private int codice1;
	private double prezzo1;

	private JLabel idProdottoLabel,nomeLabel, descrizioneLabel, codiceLabel, prezzoLabel ;
	private JTextField idProdottoField, nomeField, descrizioneField, codiceField, prezzoField;
	private JButton inserisciButton, rimuoviButton, updateButton, catalogoButton, ricercaButton;
	private static final String DB_URL = "jdbc:mysql://localhost/gestioneprodotti";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";
	Prodotto prodotto = new Prodotto(nome1, descrizione1, codice1, prezzo1);

	public GestoreProdotti() {

		idProdottoLabel = new JLabel ("Inserisci id del prodotto da rimuovere: ");
		nomeLabel = new JLabel("Inserisci il nome del prodotto: ");
		descrizioneLabel = new JLabel("Inserisci una descrizione del prodotto: ");
		codiceLabel = new JLabel ("Inserisci il codice del prodotto: ");
		prezzoLabel = new JLabel("Inserisci prezzo: ");

		idProdottoField = new JTextField();
		nomeField = new JTextField();
		descrizioneField = new JTextField();
		codiceField = new JTextField();
		prezzoField = new JTextField();

		inserisciButton = new JButton("Inserisci");
		rimuoviButton = new JButton("Rimuovi");
		updateButton = new JButton("Update");
		catalogoButton = new JButton("Catalogo");
		ricercaButton = new JButton ("Ricerca");


		JPanel panel = new JPanel(new GridLayout(8,2));

		setTitle("Inserimento dati");
		setSize(900,800);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel.add(idProdottoLabel);
		panel.add(idProdottoField);
		panel.add(nomeLabel);
		panel.add(nomeField);
		panel.add(descrizioneLabel);
		panel.add(descrizioneField);
		panel.add(codiceLabel);
		panel.add(codiceField);
		panel.add(prezzoLabel);
		panel.add(prezzoField);
		panel.add(inserisciButton);
		panel.add(updateButton);
		panel.add(rimuoviButton);
		panel.add(catalogoButton);
		panel.add(ricercaButton);

		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = nomeField.getText();
				String descrizione = descrizioneField.getText();
				int codice = (int)Integer.parseInt(codiceField.getText());
				double prezzo = (double)Double.parseDouble(prezzoField.getText());
				prodotto.inserisciProdotto(nome, descrizione, codice, prezzo);
			}
		});
		rimuoviButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int idProdotto = (int)Integer.parseInt(idProdottoField.getText());
				prodotto.rimuoviprodotto(idProdotto);
			}
		});

		updateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int idProdotto = (int)Integer.parseInt(idProdottoField.getText());
				String nome = nomeField.getText();
				String descrizione = descrizioneField.getText();
				int codice = (int)Integer.parseInt(codiceField.getText());
				double prezzo = (double)Double.parseDouble(prezzoField.getText());
				prodotto.updateProdotto(nome, descrizione, codice, prezzo, idProdotto);

			}
		});
		
		catalogoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Catalogo();
				JOptionPane.showMessageDialog(null, "File catalogo creato");
			}
		}
				);
		
		ricercaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Ricerca();
			}
		}
				);

		add(panel);
		setVisible(true);
		
	}
}
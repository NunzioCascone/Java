package Libreria;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.time.*;

public class GestioneLibreria extends JFrame{
	private JLabel idLibroLabel,titoloLabel, autoreNomeLabel, autoreCognomeLabel,idALabel, editoreLabel,idELabel, prezzoLabel ;
	private JTextField idLibroField, titoloField, autoreNomeField,autoreCognomeField,idAField, editoreField,idEField, prezzoField;
	private JButton inserisciButton, rimuoviButton, updateButton, catalogoButton, ricercaButton;
	private static final String DB_URL = "jdbc:mysql://localhost/libreria";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";

	public GestioneLibreria() {
		
		idLibroLabel = new JLabel("Id libro: ");
		titoloLabel = new JLabel("Inserisci titolo: ");
		autoreNomeLabel = new JLabel("Inserisci nome autore: ");
		autoreCognomeLabel = new JLabel("Inserisci cognome autore: ");
		idALabel = new JLabel("Inserisci id autore: ");
		editoreLabel = new JLabel("Inserisci editore: ");
		idELabel = new JLabel("Inserisci id editore: ");
		prezzoLabel = new JLabel("Inserisci prezzo: ");
		
		
		idLibroField = new JTextField(50);
		titoloField = new JTextField(50);
		autoreNomeField = new JTextField(50);
		autoreCognomeField = new JTextField(50);
		idAField = new JTextField(10);
		editoreField = new JTextField(50);
		idEField = new JTextField(10);
		prezzoField = new JTextField(10);

		inserisciButton = new JButton("Inserisci");
		rimuoviButton = new JButton("Rimuovi");
		updateButton = new JButton("Update");
		catalogoButton = new JButton("Catalogo");
		ricercaButton = new JButton ("Ricerca");
		

		JPanel panel = new JPanel(new GridLayout(13,2));

		setTitle("Inserimento dati");
		setSize(900,800);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel.add(idLibroLabel);
		panel.add(idLibroField);
		panel.add(titoloLabel);
		panel.add(titoloField);
		panel.add(autoreNomeLabel);
		panel.add(autoreNomeField);
		panel.add(autoreCognomeLabel);
		panel.add(autoreCognomeField);
		panel.add(idALabel);
		panel.add(idAField);
		panel.add(editoreLabel);
		panel.add(editoreField);
		panel.add(idELabel);
		panel.add(idEField);
		panel.add(prezzoLabel);
		panel.add(prezzoField);
		panel.add(inserisciButton);
		panel.add(updateButton);
		panel.add(rimuoviButton);
		panel.add(catalogoButton);
		panel.add(ricercaButton);
		

		inserisciButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String titolo = titoloField.getText();
				String autoreNome = autoreNomeField.getText();
				String editore = editoreField.getText();
				String autoreCognome = autoreCognomeField.getText();
				double prezzo = (double)Integer.parseInt(prezzoField.getText());
				double idAutore = (double)Integer.parseInt(idAField.getText());
				double idEditore = (double)Integer.parseInt(idEField.getText());

				Connection conn = null;
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;
				PreparedStatement stmt3 = null;
				try {
					conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
					String sql = "INSERT INTO libri(titolo,id_autore, id_editore, prezzo) VALUES(?,?,?,?)";
					String sql_editore = "insert into editori (nome) values(?)";
                    String sql_autore = "insert into autori (nome,cognome) values(?,?)";
                    
					
					
					stmt1=conn.prepareStatement(sql_editore);

                    stmt1.setString(1, editore);
                    
                    stmt1.executeUpdate();

                    stmt2=conn.prepareStatement(sql_autore);

                    stmt2.setString(1, autoreNome);
                    stmt2.setString(2, autoreCognome);
					
					stmt2.executeUpdate();
					stmt3 = conn.prepareStatement(sql);
					
					stmt3.setString(1, titolo);
					stmt3.setDouble(2, idAutore);
					stmt3.setDouble(3, idEditore);
					stmt3.setDouble(4, prezzo);
					
					stmt3.executeUpdate();
				}catch(Exception ey) {
					ey.printStackTrace();
				}finally {
					try {
						stmt3.close();
						stmt2.close();
						stmt1.close();
						conn.close();
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		}
				);
		
		
		rimuoviButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int idLibro = (int)Integer.parseInt(idLibroField.getText());
				int idAutore = (int)Integer.parseInt(idAField.getText());
				int idEditore = (int)Integer.parseInt(idEField.getText());

				Connection conn = null;
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;
				PreparedStatement stmt3 = null;
				try {
					conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
					String sql = "DELETE FROM libri WHERE id = ?";
					String sql_editore = "DELETE FROM editori WHERE id = ?";
                    String sql_autore = "DELETE FROM autori WHERE id = ?";
                    
					
					
					stmt1=conn.prepareStatement(sql_editore);
                    stmt1.setInt(1, idEditore);
                    stmt1.executeUpdate();

                    stmt2=conn.prepareStatement(sql_autore);
                    stmt2.setInt(1, idAutore);
					stmt2.executeUpdate();
					
					stmt3 = conn.prepareStatement(sql);
					stmt3.setInt(1, idLibro);
					stmt3.executeUpdate();
					
				}catch(Exception ey) {
					ey.printStackTrace();
				}finally {
					try {
						stmt3.close();
						stmt2.close();
						stmt1.close();
						conn.close();
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		}
				);
		
		
		updateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String titolo = titoloField.getText();
				String autoreNome = autoreNomeField.getText();
				String editore = editoreField.getText();
				String autoreCognome = autoreCognomeField.getText();
				double prezzo = (double)Integer.parseInt(prezzoField.getText());
				int idAutore = (int)Integer.parseInt(idAField.getText());
				int idEditore = (int)Integer.parseInt(idEField.getText());
				int idLibro = (int)Integer.parseInt(idLibroField.getText());

				Connection conn = null;
				PreparedStatement stmt1 = null;
				PreparedStatement stmt2 = null;
				PreparedStatement stmt3 = null;
				try {
					conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
					String sql = "UPDATE libri SET titolo = ?, prezzo = ?  WHERE id = ?";
					String sql_editore = "UPDATE editori SET nome = ? WHERE id = ?";
                    String sql_autore = "UPDATE autori SET nome = ?, cognome = ? WHERE id = ?";
                    
					
					
					stmt1=conn.prepareStatement(sql_editore);
                    stmt1.setString(1, editore);
                    stmt1.setInt(2, idEditore);
                    stmt1.executeUpdate();

                    stmt2=conn.prepareStatement(sql_autore);
                    stmt2.setString(1, autoreNome);
                    stmt2.setString(2, autoreCognome);
                    stmt2.setInt(3, idAutore);
					stmt2.executeUpdate();
					
					stmt3 = conn.prepareStatement(sql);
					stmt3.setString(1, titolo);
					stmt3.setDouble(2, prezzo);
					stmt3.setInt(3, idLibro);
					stmt3.executeUpdate();
				}catch(Exception ey) {
					ey.printStackTrace();
				}finally {
					try {
						stmt3.close();
						stmt2.close();
						stmt1.close();
						conn.close();
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		}
				);
		
		catalogoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Libreria();
				JOptionPane.showMessageDialog(null, "File catalogo creato");
			}
		}
				);
		
		ricercaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Ricerca();
			}
		}
				);
		
		add(panel);
		setVisible(true);
	}

}
package GestioneProdotti;

import java.util.*;
import javax.swing.*;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.time.*;

public class Login extends JFrame{
	private JLabel nomeUtenteLabel, passwordUtenteLabel;
	private JTextField nomeUtenteField, passwordUtenteField;
	private JButton accediButton;
	private static final String DB_URL = "jdbc:mysql://localhost/gestioneprodotti";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";

	public Login() {

		nomeUtenteLabel = new JLabel("Inserisci nome utente: ");
		passwordUtenteLabel = new JLabel("Inserisci password: ");

		nomeUtenteField = new JTextField(50);
		passwordUtenteField = new JPasswordField(20);

		accediButton = new JButton("Login");

		JPanel panel = new JPanel(new GridLayout(3,2));

		setTitle("Login");
		setSize(500,300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel.add(nomeUtenteLabel);
		panel.add(nomeUtenteField);
		panel.add(passwordUtenteLabel);
		panel.add(passwordUtenteField);
		panel.add(accediButton);

		accediButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nomeUtente = nomeUtenteField.getText();
				String passwordUtente = passwordUtenteField.getText();

				Connection conn = null;
				PreparedStatement stmt = null;
				String sql = "SELECT * FROM accesso";

				try {
					conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
					stmt = conn.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery("SELECT * FROM accesso WHERE nome ='" + nomeUtente + "'" + "AND password ='" + passwordUtente + "'");
					while(rs.next()) {
						if(true) {
							String nome = rs.getString("nome");
							String password = rs.getString("password");
							System.out.println(nome + password);
							if(nome.equals(nomeUtente) && password.equals(passwordUtente)) {
								System.out.println("vero");
								new GestoreProdotti();
								dispose();
							} else {
								System.out.println("falso");
							}
						}
						


					}
					rs.close();
				}catch(SQLException ex) {
					ex.printStackTrace();
				}finally {
					try {

						stmt.close();
						conn.close();
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		}
				);
		add(panel);
		setVisible(true);
	}
	public static void main(String[] args) {
		new Login();
	}
}
package Libreria;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Ricerca extends JFrame{
		
		private JLabel titoloLibroLabel;
		private JTextField titoloLibroField;
		private JButton searchButton;
		private static final String DB_URL = "jdbc:mysql://localhost/libreria";
		private static final String DB_USERNAME = "root";
		private static final String DB_PASSWORD = "BlaBlaBla24.";
		
		public Ricerca() {
			
			titoloLibroLabel = new JLabel("Inserisci il titolo da ricercare: ");
			titoloLibroField = new JTextField();
			searchButton = new JButton("Invia");
			
			JPanel panel = new JPanel(new GridLayout(2,1));
			
			setTitle("Ricerca Libro");
			setSize(500, 300);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			panel.add(titoloLibroLabel);
			panel.add(titoloLibroField);
			panel.add(searchButton);
			
			searchButton.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					
					Connection con = null;
					PreparedStatement stmt = null;
					ResultSet rs = null;
					
					try {
						con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
						String titolo = titoloLibroField.getText();
						
						String sql =("SELECT libri.titolo, libri.prezzo, autori.nome, autori.cognome FROM libri JOIN autori on libri.id = autori.id");
						
						stmt = con.prepareStatement(sql);
						rs = stmt.executeQuery(sql);

						
						PrintWriter out = new PrintWriter("libriTrovati.html");
						out.println("<html>");
						out.println("<head><title>Elenco libri</title>");
						out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\">");
						out.println("</head>");
						out.println("<body>");
						out.println("<div class=\"container\">");
						out.println("<h1 class=\"text-center\">Elenco libri</h1>");
						out.println("<table class=\"table\">");
						out.println("<thead class=\"thead-dark\"><tr><th scope=\"col\">Titolo</th><th scope=\"col\">Prezzo</th><th scope=\"col\">Nome Autore</th><th scope=\"col\">Cognome Autore</th></tr></thead>");
						out.println("<tbody>");
						
						while(rs.next()) {
							String titolo1 = rs.getString("titolo");
							double prezzo = rs.getDouble("prezzo");
							String nome = rs.getString("nome");
							String cognome = rs.getString("cognome");
							
							if(titolo1.equals(titoloLibroField.getText()) || nome.equals(titoloLibroField.getText()) || cognome.equals(titoloLibroField.getText())) {
								out.println("<tr><td>" + titolo + "</td><td>" + prezzo + "</td><td>" + nome + "</td><td>" + cognome + "</td></tr>");						
							}			
						}
						
						out.println("</tbody>");
						out.println("</table>");
						out.println("</div>");
						out.println("</body>");
						out.println("</html>");

						out.close();
						JOptionPane.showMessageDialog(null, "File Ricerca creato");
					}
					catch(Exception ex) {
						ex.printStackTrace();
					}
					finally {
						try {
							if(rs != null) {
								rs.close();
							}
							if(stmt != null) {
								stmt.close();
							}
							if(con != null) {
								con.close();
							}
						}
						catch(SQLException ex) {
							ex.printStackTrace();
						}			
					}
				}
			});
			
			setVisible(true);
			getContentPane().add(panel);
		}
		
	}

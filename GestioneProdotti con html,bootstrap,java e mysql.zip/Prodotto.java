package GestioneProdotti;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.*;

public class Prodotto extends JFrame{
	private int idProdotto;
	private String nome;
	private String descrizione;
	private int codice;
	private double prezzo;

	private JTextField idProdottoField, nomeField, descrizioneField, codiceField, prezzoField;

	private static final String DB_URL = "jdbc:mysql://localhost/gestioneprodotti";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";


	public Prodotto(String nome, String descrizione, int codice, double prezzo) {
		this.nome = nome;
		this.descrizione = descrizione;
		this.codice = codice;
		this.prezzo = prezzo;
	}

		public void inserisciProdotto(String nome, String descrizione, int codice, double prezzo) {
			this.nome = nome;
			this.descrizione = descrizione;
			this.codice = codice;
			this.prezzo = prezzo;

			Connection conn = null;
			PreparedStatement stmt1 = null;
			try {
				conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
				String sql = "INSERT INTO prodotti (nome, descrizione, codice, prezzo) VALUES(?,?,?,?)";

				stmt1=conn.prepareStatement(sql);

				stmt1.setString(1, nome);
				stmt1.setString(2, descrizione);
				stmt1.setInt(3, codice);
				stmt1.setDouble(4, prezzo);

				stmt1.executeUpdate();
			}catch(Exception ey) {
				ey.printStackTrace();
			}finally {
				try {
					stmt1.close();
					conn.close();
				}catch(SQLException ex) {
					ex.printStackTrace();
				}
			}
		}
			public void rimuoviprodotto(int idProdotto) {
				this.idProdotto = idProdotto;

				Connection conn = null;
				PreparedStatement stmt1 = null;
				try {
					conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
					String sql = "DELETE FROM prodotti WHERE id = ?";

					stmt1=conn.prepareStatement(sql);
					stmt1.setInt(1, idProdotto);
					stmt1.executeUpdate();

				}catch(Exception ey) {
					ey.printStackTrace();
				}finally {
					try {
						stmt1.close();
						conn.close();
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
			
			public void updateProdotto(String nome, String descrizione, int codice, double prezzo, int idProdotto) {
				this.nome = nome;
				this.descrizione = descrizione;
				this.codice = codice;
				this.prezzo = prezzo;
				this.idProdotto = idProdotto;

				Connection conn = null;
				PreparedStatement stmt1 = null;
				try {
					conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
					String sql = "UPDATE prodotti SET nome = ?, descrizione = ?, codice = ?, prezzo = ? WHERE id = ?";                    

					stmt1=conn.prepareStatement(sql);
					stmt1.setString(1, nome);
					stmt1.setString(2, descrizione);
					stmt1.setInt(3, codice);
					stmt1.setDouble(4, prezzo);
					stmt1.setInt(5, idProdotto);
					stmt1.executeUpdate();

				}catch(Exception ey) {
					ey.printStackTrace();
				}finally {
					try {
						stmt1.close();
						conn.close();
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
}

package GestioneProdotti;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Ricerca extends JFrame{
	
	private JLabel titoloLibroLabel;
	private JTextField titoloLibroField;
	private JButton searchButton;
	private static final String DB_URL = "jdbc:mysql://localhost/gestioneprodotti";
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";
	
	public Ricerca() {
		
		titoloLibroLabel = new JLabel("Inserisci il nome del prodotto da ricercare: ");
		titoloLibroField = new JTextField();
		searchButton = new JButton("Invia");
		
		JPanel panel = new JPanel(new GridLayout(2,1));
		
		setTitle("Ricerca prodotto");
		setSize(500, 300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel.add(titoloLibroLabel);
		panel.add(titoloLibroField);
		panel.add(searchButton);
		
		searchButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				Connection con = null;
				PreparedStatement stmt = null;
				ResultSet rs = null;
				
				try {
					con = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
					
					String sql =("SELECT*FROM prodotti");
					
					stmt = con.prepareStatement(sql);
					rs = stmt.executeQuery(sql);

					
					PrintWriter out = new PrintWriter("prodottiTrovati.html");
					out.println("<html>");
					out.println("<head><title>Elenco libri</title>");
					out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\">");
					out.println("</head>");
					out.println("<body>");
					out.println("<div class=\"container\">");
					out.println("<h1 class=\"text-center\">Elenco libri</h1>");
					out.println("<table class=\"table\">");
					out.println("<thead class=\"thead-dark\"><tr><th scope=\"col\">Titolo</th><th scope=\"col\">Prezzo</th><th scope=\"col\">Nome Autore</th><th scope=\"col\">Cognome Autore</th></tr></thead>");
					out.println("<tbody>");
					
					while(rs.next()) {
						String nome = rs.getString("nome");
						String descrizione = rs.getString("descrizione");
						int codice = rs.getInt("codice");
						double prezzo = rs.getDouble("prezzo");
						
						if(nome.equals(titoloLibroField.getText())) {
							out.println("<tr><td>" + nome + "</td><td>" + descrizione + "</td><td>" + codice + "</td><td>" + prezzo + "</td></tr>");						
						}			
					}
					
					out.println("</tbody>");
					out.println("</table>");
					out.println("</div>");
					out.println("</body>");
					out.println("</html>");

					out.close();
					JOptionPane.showMessageDialog(null, "File Ricerca creato");
				}
				catch(Exception ex) {
					ex.printStackTrace();
				}
				finally {
					try {
						if(rs != null) {
							rs.close();
						}
						if(stmt != null) {
							stmt.close();
						}
						if(con != null) {
							con.close();
						}
					}
					catch(SQLException ex) {
						ex.printStackTrace();
					}			
				}
			}
		});
		
		setVisible(true);
		getContentPane().add(panel);
	}
	
}

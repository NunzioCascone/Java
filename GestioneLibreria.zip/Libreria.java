package Libreria;

import java.util.*;
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.time.*;
import java.io.*;

public class Libreria{
	private static final String DB_URL = "jdbc:mysql://localhost/libreria";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";


	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs2 = null;
public Libreria() {
	try {
		conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

		stmt = conn.createStatement();
		rs = stmt.executeQuery("SELECT libri.titolo, libri.prezzo, autori.nome, autori.cognome FROM libri JOIN autori on libri.id = autori.id");

		PrintWriter out = new PrintWriter("libri.html");
		out.println("<html>");
		out.println("<head><title>Elenco libri</title>");
		out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\">");
		out.println("</head>");
		out.println("<body>");
		out.println("<div class=\"container\">");
		out.println("<h1 class=\"text-center\">Elenco libri</h1>");
		out.println("<table class=\"table\">");
		out.println("<thead class=\"thead-dark\"><tr><th scope=\"col\">Titolo</th><th scope=\"col\">Prezzo</th><th scope=\"col\">Nome Autore</th><th scope=\"col\">Cognome Autore</th></tr></thead>");
		out.println("<tbody>");
		while(rs.next()) {
			String titolo = rs.getString("titolo");
			double prezzo = rs.getDouble("prezzo");
			String nome = rs.getString("nome");
			String cognome = rs.getString("cognome");
			out.println("<tr><td>" + titolo + "</td><td>" + prezzo + "</td><td>" + nome + "</td><td>" + cognome + "</td></tr>");
		}
		out.println("</tbody>");
		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");

		out.close();


	} catch (Exception e){
		e.getMessage();
	}finally {
		//chiude connessione al database
		try {
			if(rs!=null) {
				rs.close();
			}
			if(rs2!=null) {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}
}
}

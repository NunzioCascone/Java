package GestioneProdotti;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.*;
import java.util.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Catalogo {
	private static final String DB_URL = "jdbc:mysql://localhost/gestioneprodotti";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "BlaBlaBla24.";


	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
public Catalogo() {
	try {
		conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);

		stmt = conn.createStatement();
		rs = stmt.executeQuery("SELECT*FROM prodotti");

		PrintWriter out = new PrintWriter("catalogo.html");
		out.println("<html>");
		out.println("<head><title>Elenco prodotti</title>");
		out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\">");
		out.println("</head>");
		out.println("<body>");
		out.println("<div class=\"container\">");
		out.println("<h1 class=\"text-center\">Elenco prodotti</h1>");
		out.println("<table class=\"table\">");
		out.println("<thead class=\"thead-dark\"><tr><th scope=\"col\">Nome</th><th scope=\"col\">Descrizione</th><th scope=\"col\">Codice</th><th scope=\"col\">Prezzo</th></tr></thead>");
		out.println("<tbody>");
		while(rs.next()) {
			String nome = rs.getString("nome");
			String descrizione = rs.getString("descrizione");
			int codice = rs.getInt("codice");
			double prezzo = rs.getDouble("prezzo");
			out.println("<tr><td>" + nome + "</td><td>" + descrizione + "</td><td>" + codice + "</td><td>" + prezzo + "</td></tr>");
		}
		out.println("</tbody>");
		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");

		out.close();


	} catch (Exception e){
		e.getMessage();
	}finally {
		//chiude connessione al database
		try {
			if(rs!=null) {
				rs.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}
}

}
